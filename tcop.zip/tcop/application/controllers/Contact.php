<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Contact extends CI_Controller
{


    public function index()
    {
        $this->load->view('users/includes/header');
        $this->load->view('users/contact');
        $this->load->view('users/includes/footer');
    }
}
