<!DOCTYPE html>
<html lang="en">

<head>
    <!-- meta tags -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="keywords" content="">

    <!-- title -->
    <title>Tulaskar College of Pharmacy Hinganghat Dist. Wardha 442301</title>

    <!-- favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/logo/favicon.png">

    <!-- css -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all-fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
</head>

<body class="home-3">

    <!-- preloader -->
    <div class="preloader">
        <div class="loader-book">
            <div class="loader-book-page"></div>
            <div class="loader-book-page"></div>
            <div class="loader-book-page"></div>
        </div>
    </div>
    <!-- preloader end -->

    <!-- header area -->
    <header class="header">
        <!-- header top -->
        <div class="header-top">
            <div class="container">
                <div class="header-top-wrap">
                    <div class="header-top-left">
                        <p class="header-top-news">Welcome ! Tulaskar College of Pharmacy, Hinganghat.</p>
                    </div>
                    <div class="header-top-right">
                        <div class="header-top-menu">
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="main-navigation">
            <div class="logo-header">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-md-2">
                            <div class="logo__one logo__img">
                                <img src="assets/img/logo/logo-1.png" class="img-fluid">
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="logo_content">
                                <span class="top">Vidya Vikas Shikshan Sanstha’s</span>
                                <h2>Tulaskar College of Pharmacy</h2>
                                <strong>Hinganghat Dist. Wardha 442301</strong>
                                <p>Approved by PCI, New Delhi & DTE Maharashtra <span>(DTE Code – 04751)</span> Affiliated to DBATU, Lonere & MSBTE, Mumbai</p>
                            </div>
                        </div>
                        <div class="col-md-2 text-end">
                            <div class="logo__one logo__img">
                                <img src="assets/img/logo/logo-2.png" class="img-fluid">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <nav class="navbar navbar-expand-lg">
                <div class="container position-relative">
                    <!-- <a class="navbar-brand" href="index-2.html">
                        <img src="assets/img/logo/logo.png" alt="logo">
                    </a> -->
                    <div class="mobile-menu-right">
                        <div class="search-btn">
                            <button type="button" class="nav-right-link search-box-outer"><i
                                    class="far fa-search"></i></button>
                        </div>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                            data-bs-target="#main_nav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-mobile-icon"><i class="far fa-bars"></i></span>
                        </button>
                    </div>
                    <div class="collapse navbar-collapse" id="main_nav">
                        <ul class="navbar-nav">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle active" href="#" data-bs-toggle="dropdown">Home</a>
                                <ul class="dropdown-menu fade-down">
                                    <li><a class="dropdown-item" href="index-2.html">Home Page 01</a></li>
                                    <li><a class="dropdown-item" href="index-3.html">Home Page 02</a></li>
                                    <li><a class="dropdown-item" href="index-4.html">Home Page 03</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Courses</a>
                                <ul class="dropdown-menu fade-down">
                                    <li><a class="dropdown-item" href="course.html">Courses One</a></li>
                                    <li><a class="dropdown-item" href="course-2.html">Courses Two</a></li>
                                    <li><a class="dropdown-item" href="course-single.html">Course Single One</a></li>
                                    <li><a class="dropdown-item" href="course-single-2.html">Course Single Two</a></li>
                                </ul>
                            </li>
                            <li class="nav-item mega-menu dropdown">
                                <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Academics</a>
                                <div class="dropdown-menu fade-down">
                                    <div class="mega-content">
                                        <div class="container-fluid">
                                            <div class="row">
                                                <div class="col-12 col-sm-4 col-md-3">
                                                    <h5>About Us</h5>
                                                    <div class="menu-about">
                                                        <a href="#" class="menu-about-logo"><img
                                                                src="assets/img/logo/logo-light.png" alt=""></a>
                                                        <p>We are many variations of passages available but the majority
                                                            have suffered alteration in some form by injected humour
                                                            words injected humour believable.</p>
                                                    </div>
                                                </div>
                                                <div class="col-12 col-sm-4 col-md-3">
                                                    <h5>Undergraduate</h5>
                                                    <ul class="mega-menu-item">
                                                        <li><a class="dropdown-item" href="academic-single.html">Art And
                                                                Design</a></li>
                                                        <li><a class="dropdown-item" href="academic-single.html">Acting
                                                                And Drama</a></li>
                                                        <li><a class="dropdown-item"
                                                                href="academic-single.html">Accounting And Finance</a>
                                                        </li>
                                                        <li><a class="dropdown-item" href="academic-single.html">Biology
                                                                And Conservation</a></li>
                                                        <li><a class="dropdown-item" href="academic-single.html">Science
                                                                And Engineering</a></li>
                                                    </ul>
                                                </div>
                                                <div class="col-12 col-sm-4 col-md-3">
                                                    <h5>Graduate Program</h5>
                                                    <ul class="mega-menu-item">
                                                        <li><a class="dropdown-item"
                                                                href="academic-single.html">Software Systems</a></li>
                                                        <li><a class="dropdown-item" href="academic-single.html">Human
                                                                Resource</a></li>
                                                        <li><a class="dropdown-item" href="academic-single.html">Health
                                                                Administration</a></li>
                                                        <li><a class="dropdown-item"
                                                                href="academic-single.html">Biochemistry</a></li>
                                                        <li><a class="dropdown-item"
                                                                href="academic-single.html">Computer Science</a></li>
                                                    </ul>
                                                </div>
                                                <div class="col-12 col-sm-12 col-md-3">
                                                    <h5>Resources</h5>
                                                    <ul class="mega-menu-item">
                                                        <li><a class="dropdown-item" href="academic.html">Academics
                                                                Department</a></li>
                                                        <li><a class="dropdown-item"
                                                                href="academic-single.html">Academic Department
                                                                Single</a></li>
                                                        <li><a class="dropdown-item" href="faculty.html">Our Faculty</a>
                                                        </li>
                                                        <li><a class="dropdown-item" href="faculty-single.html">Faculty
                                                                Single</a></li>
                                                        <li><a class="dropdown-item" href="contact.html">Contact With
                                                                Us</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Blog</a>
                                <ul class="dropdown-menu fade-down">
                                    <li><a class="dropdown-item" href="blog.html">Blog</a></li>
                                    <li><a class="dropdown-item" href="blog-single.html">Blog Single</a></li>
                                </ul>
                            </li>
                            <li class="nav-item"><a class="nav-link" href="contact.html">Contact</a></li>
                        </ul>
                        <!-- <div class="nav-right">
                            <div class="search-btn">
                                <button type="button" class="nav-right-link search-box-outer"><i
                                        class="far fa-search"></i></button>
                            </div>
                            <div class="nav-right-btn mt-2">
                                <a href="application-form.html" class="theme-btn"><span
                                        class="fal fa-pencil"></span>Apply Now</a>
                            </div>
                        </div> -->
                    </div>
                </div>
            </nav>
        </div>
    </header>
    <!-- header area end -->


    <!-- popup search -->
    <div class="search-popup">
        <button class="close-search"><span class="far fa-times"></span></button>
        <form action="#">
            <div class="form-group">
                <input type="search" name="search-field" placeholder="Search Here..." required>
                <button type="submit"><i class="far fa-search"></i></button>
            </div>
        </form>
    </div>
    <!-- popup search end -->


